# Expo → Cloudflare deployment bundle

This bundle gives you a minimal, production-oriented setup for deploying an **Expo web** app to **Cloudflare Pages** from **GitHub Actions**.

## What is included

- `.github/workflows/deploy-cloudflare-expo.yml` — deploy workflow
- `.github/actions/expo-caches/action.yml` — local composite action for Expo caching
- `package.json` — build scripts for Expo web
- `app.json` — Expo app config
- `scripts/ensure-cloudflare-build.mjs` — validates the static export output
- `wrangler.toml` — optional Cloudflare project config
- `.gitignore` — standard ignores

## Expected repo shape

Copy these files into the root of your Expo project. If your Expo app already has `package.json` and `app.json`, merge carefully instead of overwriting.

## Required GitHub secrets

Add these repository secrets:

- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_PROJECT_NAME`

## Build output

The workflow exports Expo web to the `dist/` directory and deploys that directory to Cloudflare Pages.

## Notes

- This setup assumes `expo export --platform web` is the source of truth.
- If your app uses server-only features, Cloudflare Pages static hosting may not be enough.
- If your existing app uses a monorepo, adjust the workflow `working-directory` and cache paths.
