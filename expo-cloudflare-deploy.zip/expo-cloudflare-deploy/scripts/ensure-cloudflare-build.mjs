import fs from 'node:fs';
import path from 'node:path';

const outDir = path.resolve('dist');
const indexHtml = path.join(outDir, 'index.html');

if (!fs.existsSync(outDir)) {
  console.error('Cloudflare deploy check failed: dist/ does not exist.');
  process.exit(1);
}

if (!fs.existsSync(indexHtml)) {
  console.error('Cloudflare deploy check failed: dist/index.html is missing.');
  process.exit(1);
}

const stats = fs.statSync(indexHtml);
if (stats.size === 0) {
  console.error('Cloudflare deploy check failed: dist/index.html is empty.');
  process.exit(1);
}

console.log('Cloudflare deploy check passed. Static Expo export is ready in dist/.');
